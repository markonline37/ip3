google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(myFunction);

function myFunction() {
	$.ajax({
		url: "https://omgvamp-hearthstone-v1.p.rapidapi.com/cards",
		headers: {
			'X-RapidAPI-Key':'YOUR-RAPIDAPI-KEY-HERE'
		},
		success: function(data){
			count(data);
		}
	});
}

function count(data){
	var hasHealth = 0;
	var oneHealth = 0;
	var twoHealth = 0;
	for(var i = 0; i < data['Basic'].length; i++){
		if(data['Basic'][i].hasOwnProperty('health')){
			hasHealth++;
			if(data['Basic'][i].health === 1){
				oneHealth++;
			} else if(data['Basic'][i].health === 2){
				twoHealth++;
			}
		}
	}
	displayChart(hasHealth, oneHealth, twoHealth);
}

function displayChart(input1, input2, input3){
	var data = google.visualization.arrayToDataTable([
		['Card Name', 'Type'],
		['Total Cards with health', input1],
		['Cards with 1 Health', input2],
		['Cards with 2 Health', input3]
	]);

	var options = {
		bars: 'horizontal'
	};

	var chart = new google.charts.Bar(document.getElementById('chart_div'));
	chart.draw(data, options);
}